<?php
namespace Awz\Acl\Access\Custom;

use Awz\Acl\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}