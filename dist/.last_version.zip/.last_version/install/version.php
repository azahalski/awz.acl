<?
$arModuleVersion = array(
	"VERSION" => "1.1.4",
	"VERSION_DATE" => "2025-06-13 20:05:00"
);
?>