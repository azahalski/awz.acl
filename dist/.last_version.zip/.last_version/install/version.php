<?
$arModuleVersion = array(
	"VERSION" => "1.1.5",
	"VERSION_DATE" => "2025-06-13 20:05:00"
);
?>