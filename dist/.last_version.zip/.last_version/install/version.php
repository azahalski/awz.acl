<?
$arModuleVersion = array(
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2025-06-12 06:44:00"
);
?>