<?
$arModuleVersion = array(
	"VERSION" => "1.1.6",
	"VERSION_DATE" => "2025-07-18 05:47:00"
);
?>