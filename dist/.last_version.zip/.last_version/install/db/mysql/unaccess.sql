drop table if exists awz_acl_role;
drop table if exists awz_acl_role_relation;
drop table if exists awz_acl_permission;